#!/usr/bin/env bash
set -euo pipefail

# ================================================================
# Hermes Backup Script — backs up critical config & data to GitHub
# Uses HTTPS (port 443) instead of SSH (port 22 is blocked).
# ================================================================

REPO_URL="https://github.com/davoodmalekm-dev/assholebackup.git"
GITHUB_TOKEN="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"
BACKUP_DIR="/tmp/hermes-backup-$(date +%s)"
HERMES_HOME="${HOME}/.hermes"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE_NAME="hermes-full-backup-${TIMESTAMP}.tar.gz"

# Cleanup on exit
cleanup() {
    rm -rf "${BACKUP_DIR}"
}
trap cleanup EXIT

echo "=== Hermes Backup — ${TIMESTAMP} ==="
echo ""

# Step 1: Prepare working directory
mkdir -p "${BACKUP_DIR}/hermes"

# Step 2: Collect critical files — preserve directory structure
echo "[1/4] Collecting Hermes files..."

# Config and core
cp -a "${HERMES_HOME}/config.yaml"    "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/SOUL.md"        "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/.env"           "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/auth.json"      "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/channel_directory.json" "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/gateway_state.json"    "${BACKUP_DIR}/hermes/" 2>/dev/null || true

# State database
cp -a "${HERMES_HOME}/state.db"       "${BACKUP_DIR}/hermes/" 2>/dev/null || true
cp -a "${HERMES_HOME}/kanban.db"      "${BACKUP_DIR}/hermes/" 2>/dev/null || true

# Session index (not full request dumps — those are large & reconstrucible)
cp -a "${HERMES_HOME}/sessions/sessions.json" "${BACKUP_DIR}/hermes/sessions.json" 2>/dev/null || true

# Memories
if [ -d "${HERMES_HOME}/memories" ] && [ "$(ls -A "${HERMES_HOME}/memories" 2>/dev/null)" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/memories"
    cp -a "${HERMES_HOME}/memories/"* "${BACKUP_DIR}/hermes/memories/" 2>/dev/null || true
fi

# Skills
if [ -d "${HERMES_HOME}/skills" ] && [ "$(ls -A "${HERMES_HOME}/skills" 2>/dev/null)" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/skills"
    cp -a "${HERMES_HOME}/skills/"* "${BACKUP_DIR}/hermes/skills/" 2>/dev/null || true
fi

# Cron jobs (executions db + output)
if [ -d "${HERMES_HOME}/cron" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/cron"
    cp -a "${HERMES_HOME}/cron/executions.db" "${BACKUP_DIR}/hermes/cron/" 2>/dev/null || true
    [ -d "${HERMES_HOME}/cron/output" ] && cp -a "${HERMES_HOME}/cron/output" "${BACKUP_DIR}/hermes/cron/" 2>/dev/null || true
fi

# Hooks
if [ -d "${HERMES_HOME}/hooks" ] && [ "$(ls -A "${HERMES_HOME}/hooks" 2>/dev/null)" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/hooks"
    cp -a "${HERMES_HOME}/hooks/"* "${BACKUP_DIR}/hermes/hooks/" 2>/dev/null || true
fi

# Platforms
if [ -d "${HERMES_HOME}/platforms" ] && [ "$(ls -A "${HERMES_HOME}/platforms" 2>/dev/null)" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/platforms"
    cp -a "${HERMES_HOME}/platforms/"* "${BACKUP_DIR}/hermes/platforms/" 2>/dev/null || true
fi

# Logs (last 100 lines summary)
if [ -d "${HERMES_HOME}/logs" ]; then
    mkdir -p "${BACKUP_DIR}/hermes/logs"
    for logf in "${HERMES_HOME}/logs/"*.log; do
        [ -f "${logf}" ] && tail -100 "${logf}" > "${BACKUP_DIR}/hermes/logs/$(basename "${logf}")" 2>/dev/null || true
    done
fi

# Backup script itself
cp -a "${HERMES_BIN_DIR:-${HERMES_HOME}/bin}/backup.sh" "${BACKUP_DIR}/hermes/" 2>/dev/null || true

echo "       Collected $(du -sh "${BACKUP_DIR}" | cut -f1) of data"

# Step 3: Create compressed archive
echo "[2/4] Creating archive..."
cd "${BACKUP_DIR}"
tar -czf "/tmp/${ARCHIVE_NAME}" hermes/
echo "       Archive: /tmp/${ARCHIVE_NAME} ($(du -sh "/tmp/${ARCHIVE_NAME}" | cut -f1))"

# Step 4: Clone/push to GitHub
echo "[3/4] Connecting to GitHub..."
WORK_DIR="/tmp/hermes-git-repo"

if [ -d "${WORK_DIR}" ]; then
    cd "${WORK_DIR}"
    git pull origin main 2>&1 || git pull origin master 2>&1 || true
else
    git clone "https://${GITHUB_TOKEN}@github.com/davoodmalekm-dev/assholebackup.git" "${WORK_DIR}"
    cd "${WORK_DIR}"
fi

# Copy archive into repo
mv "/tmp/${ARCHIVE_NAME}" "${WORK_DIR}/"

# Generate a manifest/readable index
cat > "${WORK_DIR}/LATEST.md" << EOF
# Hermes Backup — ${TIMESTAMP}

**Backup Time:** $(date '+%Y-%m-%d %H:%M:%S UTC')
**Archive:** ${ARCHIVE_NAME}
**Size:** $(du -sh "${WORK_DIR}/${ARCHIVE_NAME}" | cut -f1)

## Contents
- \`config.yaml\` — Main configuration
- \`SOUL.md\` — System identity/soul
- \`.env\` — Environment variables
- \`auth.json\` — Authentication data
- \`channel_directory.json\` — Channel/platform registry
- \`gateway_state.json\` — Gateway state
- \`state.db\` — Hermes state database
- \`kanban.db\` — Kanban/task database
- \`sessions.json\` — Session index
- \`memories/\` — Persistent memory files
- \`skills/\` — Installed skills
- \`cron/\` — Cron job data
- \`hooks/\` — Hook scripts
- \`platforms/\` — Platform configurations
- \`logs/\` — Recent log summaries
EOF

# Also update INDEX.md (append this backup)
if [ ! -f "${WORK_DIR}/INDEX.md" ]; then
    echo "# Hermes Backup Index" > "${WORK_DIR}/INDEX.md"
    echo "" >> "${WORK_DIR}/INDEX.md"
    echo "| Timestamp | Archive | Size |" >> "${WORK_DIR}/INDEX.md"
    echo "|-----------|---------|------|" >> "${WORK_DIR}/INDEX.md"
fi
SIZE_HR=$(du -sh "${WORK_DIR}/${ARCHIVE_NAME}" | cut -f1)
echo "| ${TIMESTAMP} | \`${ARCHIVE_NAME}\` | ${SIZE_HR} |" >> "${WORK_DIR}/INDEX.md"

# Commit and push
git add -A
git commit -m "Hermes backup ${TIMESTAMP}" --allow-empty
git push "https://${GITHUB_TOKEN}@github.com/davoodmalekm-dev/assholebackup.git" main 2>&1 || git push "https://${GITHUB_TOKEN}@github.com/davoodmalekm-dev/assholebackup.git" master 2>&1

echo ""
echo "[4/4] Cleanup..."
rm -f "/tmp/${ARCHIVE_NAME}"

echo ""
echo "=== Backup complete! ==="
echo "Pushed: ${ARCHIVE_NAME}"
